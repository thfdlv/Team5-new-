package com.example.jsonExam.image;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;

@Controller
@RequestMapping("/image")
public class ImageController {

	@PostMapping("/upload")
	public String uploadImage(MultipartFile imageFile) {
	    if (imageFile.isEmpty()) return "redirect:/error";

	    try {
	        String filePath = "/tmp/" + imageFile.getOriginalFilename();
	        imageFile.transferTo(new File(filePath));
	        System.out.println("업로드 성공: " + filePath);
	    } catch (IOException e) {
	        e.printStackTrace();
	    }

	    return "image-upload";
	}
}
