package com.example.jsonExam.community.post;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jsonExam.community.comment.CommentDTO;
import com.example.jsonExam.community.comment.CommentMapper;
import com.example.jsonExam.community.commentlike.CommentLikeService; // ✅ 댓글 좋아요 서비스
import com.example.jsonExam.community.like.LikeService;

import java.util.List;
import java.time.LocalDateTime;

@Service
public class PostService {
    @Autowired private PostMapper postMapper;
    @Autowired private CommentMapper commentMapper;
    @Autowired private LikeService likeService;
    @Autowired private CommentLikeService commentLikeService; // ✅ 추가

    public void createPost(PostDTO post) {
        if (post.getCreatedAt() == null) {
            post.setCreatedAt(LocalDateTime.now());
        }
        if (post.getAuthor() == null || post.getAuthor().trim().isEmpty()) {
            post.setAuthor("익명");
        }
        postMapper.createPost(post);
    }

    public PostDTO getPostById(int id) {
        PostDTO post = postMapper.getPostById(id);
        List<CommentDTO> comments = commentMapper.getCommentsByPostId(post.getId());

        // ✅ 각 댓글에 좋아요 수 추가
        for (CommentDTO comment : comments) {
            int likeCount = commentLikeService.getLikeCount(comment.getId());
            comment.setLikeCount(likeCount);
        }

        post.setComments(comments);
        post.setLikeCount(likeService.getLikeCount(post.getId()));
        return post;
    }

    public List<PostDTO> getAllPosts() {
        List<PostDTO> posts = postMapper.getAllPosts();
        System.out.println("📢 서비스 - DB에서 가져온 게시글 개수: " + posts.size());

        for (PostDTO post : posts) {
            List<CommentDTO> comments = commentMapper.getCommentsByPostId(post.getId());

            // ✅ 각 댓글에 좋아요 수 추가
            for (CommentDTO comment : comments) {
                int likeCount = commentLikeService.getLikeCount(comment.getId());
                comment.setLikeCount(likeCount);
            }

            post.setComments(comments);
            post.setLikeCount(likeService.getLikeCount(post.getId()));
        }

        return posts;
    }

    public void updatePost(PostDTO post) {
        postMapper.createPost(post);
    }

    public void deletePost(int id) {
        postMapper.deletePost(id);
    }
}
