package com.example.jsonExam.community.post;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import jakarta.servlet.http.HttpSession;

import java.util.List;

@Controller
@RequestMapping("/post")
public class PostController {

    @Autowired 
    private PostService postService;

    /**
     * ✅ 게시글 목록 조회
     */
    @GetMapping("/community")
    public String community(Model model) {
        return list(model); // 목록 재사용
    }
    
    @GetMapping("/list")
    public String list(Model model) {
        List<PostDTO> posts = postService.getAllPosts();
        
        // ✅ 가져온 게시글 개수 확인
        System.out.println("📢 컨트롤러 - 가져온 게시글 개수: " + posts.size());

        // ✅ requestScope에 데이터 저장
        model.addAttribute("posts", posts);

        return "community";  // ✅ JSP 경로 확인
    }

    /**
     * ✅ 특정 게시글 조회
     */
    @GetMapping("/view")
    public String view(@RequestParam("id") int id, Model model) {
        PostDTO post = postService.getPostById(id);
        if (post == null) {
            return "redirect:http://www.team5.click/project1/community";  // ✅ 게시글이 없을 경우 목록으로 리다이렉트
        }
        model.addAttribute("post", post);
        return "post-page";  // ✅ JSP 파일 경로 확인
    }

    /**
     * ✅ 게시글 생성
     */
    @PostMapping("/create")
    public String create(@ModelAttribute PostDTO post, 
                         HttpSession session,
                         RedirectAttributes redirectAttributes) {
        try {
            // ✅ 세션에서 사용자 ID 가져오기
            String userId = (String) session.getAttribute("id");

            // ✅ authorId 설정
            post.setAuthorId(userId);

            postService.createPost(post);
            redirectAttributes.addFlashAttribute("message", "게시글이 등록되었습니다.");
            return "redirect:/community";  
        } catch (Exception e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "게시글 등록 중 오류 발생!");
            return "redirect:/community";  
        }
    }

    /**
     * ✅ 게시글 수정
     */
    @PostMapping("/update")
    public String update(@ModelAttribute PostDTO post) {
        postService.updatePost(post);
        return "redirect:http://www.team5.click/project1/post/view?id=" + post.getId();
    }

    /**
     * ✅ 게시글 삭제
     */
    @PostMapping("/delete")
    public String deletePost(@RequestParam("id") int id, HttpSession session, RedirectAttributes ra) {
        String sessionId = (String) session.getAttribute("id");
        PostDTO post = postService.getPostById(id);

        // 세션이 없거나 본인이 작성한 글이 아니면 삭제 못함
        if (sessionId == null || post == null || !sessionId.equals(post.getAuthorId())) {
            ra.addFlashAttribute("error", "본인이 작성한 글만 삭제할 수 있습니다.");
            return "redirect:/post/list";
        }

        postService.deletePost(id);
        ra.addFlashAttribute("message", "게시글이 삭제되었습니다.");
        return "redirect:/post/list";
    }
}