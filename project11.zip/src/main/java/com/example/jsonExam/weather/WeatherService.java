package com.example.jsonExam.weather;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class WeatherService {

    private final RestTemplate restTemplate = new RestTemplate();

    private static final String API_URL = "http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getVilageFcst";
    private static final String API_KEY = "83J%2BZlSbumSCc2rBcCipXddnGvjm7eTJIpu6ZFEJFY3BV2SqHP3VsxxsXK3m5jQhb8D%2FoXKVulq5Gv4xzLu72Q%3D%3D";
    private static final String PAGE_NO = "1";
    private static final String PAGE_SIZE = "100";

    public WeatherModel.WeatherResponse getUltraSrtNcst() throws URISyntaxException {
        LocalDateTime now = LocalDateTime.now();

        // 예보는 3시간 간격: 02, 05, 08, 11, 14, 17, 20, 23 중 가장 가까운 이전 시간
        String baseTime = getBaseTime(now);
        String baseDate = now.getHour() < 2 ? now.minusDays(1).format(DateTimeFormatter.ofPattern("yyyyMMdd"))
                                            : now.format(DateTimeFormatter.ofPattern("yyyyMMdd"));

        URI uri = new URI(API_URL
                + "?serviceKey=" + API_KEY
                + "&numOfRows=" + PAGE_SIZE
                + "&pageNo=" + PAGE_NO
                + "&base_date=" + baseDate
                + "&base_time=" + baseTime
                + "&nx=55&ny=127"  // 서울시청 기준 좌표
                + "&dataType=JSON");

        WeatherModel.WeatherSearchData weather =
                restTemplate.getForObject(uri, WeatherModel.WeatherSearchData.class);

        if (weather == null || weather.getWeatherItems() == null) {
            throw new IllegalStateException("날씨 데이터 조회 실패");
        }

        List<WeatherModel.WeatherItem> weatherItems = weather.getWeatherItems();

        String temp = getWeatherInfo(weatherItems, "TMP");
        String moisture = getWeatherInfo(weatherItems, "REH");
        String windSpeed = getWeatherInfo(weatherItems, "WSD");

        return new WeatherModel.WeatherResponse(temp, moisture, windSpeed, baseDate);
    }

    // 가장 최근의 유효한 base_time 계산
    private String getBaseTime(LocalDateTime now) {
        int hour = now.getHour();
        int[] baseHours = {23, 20, 17, 14, 11, 8, 5, 2};

        for (int h : baseHours) {
            if (hour >= h) {
                return String.format("%02d00", h);
            }
        }
        return "2300"; // 0~1시 사이면 전날 23시
    }

    private String getWeatherInfo(List<WeatherModel.WeatherItem> weatherItems, String category) {
        return weatherItems.stream()
                .filter(it -> it.getCategory().equals(category))
                .findFirst()
                .map(WeatherModel.WeatherItem::getFcstValue)
                .orElse("N/A");
    }
}
