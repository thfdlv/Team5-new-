package com.example.jsonExam.community.like;

public class LikeDTO {
    private int id;
    private int postId;
    private String userId;
	public String getPostId() {
		// TODO Auto-generated method stub
		return null;
	}

    // Getter & Setter
}

